<?php

use App\Http\Controllers\Api\ScormApiController;
use App\Http\Controllers\Platform\SubscriptionPlanController;
use App\Http\Controllers\Platform\TenantSubscriptionController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\SsoController;
use App\Http\Controllers\Auth\TwoFactorController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\Auth\ForgotPasswordController;
use App\Http\Controllers\Auth\ResetPasswordController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\Platform\AuditLogController;
use App\Http\Controllers\Platform\TenantController;
use App\Http\Controllers\Platform\PlatformSettingController;
use App\Http\Controllers\Platform\PlatformUserController;
use App\Http\Controllers\Platform\CourseManagementController;
use App\Http\Controllers\Platform\CourseCategoryController;
use App\Http\Controllers\Platform\ReportController as PlatformReportController;
use App\Http\Controllers\Platform\TenantSsoController;
use App\Http\Controllers\Client\ReportController as ClientReportController;
use App\Http\Controllers\Client\UserController;
use App\Http\Controllers\Client\DepartmentController;
use App\Http\Controllers\Client\AssignmentController as ClientAssignmentController;
use App\Http\Controllers\Client\ClientCourseController;
use App\Http\Controllers\Client\PhishingController;
use App\Http\Controllers\Client\PolicyController;
use App\Http\Controllers\Client\AnnouncementController as ClientAnnouncementController;
use App\Http\Controllers\Client\SurveyController as ClientSurveyController;
use App\Http\Controllers\Client\VirtualClassroomController as ClientVirtualClassroomController;
use App\Http\Controllers\Employee\AnnouncementController as EmployeeAnnouncementController;
use App\Http\Controllers\Employee\SurveyController as EmployeeSurveyController;
use App\Http\Controllers\Employee\VirtualClassroomController as EmployeeVirtualClassroomController;
use App\Http\Controllers\Employee\AssignmentController as EmployeeAssignmentController;
use App\Http\Controllers\Employee\CertificateController;
use App\Http\Controllers\Employee\ExternalCredentialController;
use App\Http\Controllers\Employee\CourseController;
use App\Http\Controllers\Client\CredentialController as ClientCredentialController;
use App\Http\Controllers\Employee\LeaderboardController;
use App\Http\Controllers\Employee\LearningPathController as EmployeeLearningPathController;
use App\Http\Controllers\Platform\LearningPathController as PlatformLearningPathController;
use App\Http\Controllers\Client\ClientLearningPathController;
use App\Http\Controllers\Employee\PolicyAcknowledgmentController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\SessionController;
use App\Http\Controllers\Client\ClientSettingsController;
use App\Http\Controllers\Client\AiToolsController;
use App\Http\Controllers\Client\ClientSsoController;
use App\Http\Controllers\LocaleController;
use App\Http\Controllers\SecuritySettingsController;
use App\Http\Controllers\CertificateVerificationController;
use Illuminate\Support\Facades\Route;

// ── Public ──
Route::get('/', function () {
    return redirect()->route('login');
});

// ── Certificate Verification (Public, no auth) ──
Route::get('verify', [CertificateVerificationController::class, 'verify'])->name('certificates.verify');
Route::post('verify', [CertificateVerificationController::class, 'check'])->name('certificates.check');
Route::get('verify/{code}', [CertificateVerificationController::class, 'check'])->name('certificates.verify.code');

Route::post('locale/{locale}', [LocaleController::class, 'update'])->name('locale.update');

// ── Auth (Guest) ──
Route::middleware('guest')->group(function () {
    Route::get('login', [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('login', [LoginController::class, 'login']);
    Route::post('login/check-sso', [LoginController::class, 'checkSso'])->name('login.check-sso');
    Route::get('forgot-password', [ForgotPasswordController::class, 'showForm'])->name('password.request');
    Route::post('forgot-password', [ForgotPasswordController::class, 'sendResetLink'])->name('password.email');
    Route::get('reset-password/{token}', [ResetPasswordController::class, 'showForm'])->name('password.reset');
    Route::post('reset-password', [ResetPasswordController::class, 'reset'])->name('password.update');

    // SSO
    Route::get('sso/{provider}/redirect', [SsoController::class, 'redirect'])->name('sso.redirect');
    Route::get('sso/{provider}/callback', [SsoController::class, 'callback'])->name('sso.callback');

    // 2FA Challenge (user is not yet fully authenticated)
    Route::get('two-factor/challenge', [TwoFactorController::class, 'challenge'])->name('two-factor.challenge')->withoutMiddleware('guest');
    Route::post('two-factor/verify', [TwoFactorController::class, 'verifyChallenge'])->name('two-factor.verify')->withoutMiddleware('guest');
});

// ── Authenticated ──
Route::middleware(['auth', 'resolve.tenant', 'inject.branding'])->group(function () {
    Route::post('logout', [LoginController::class, 'logout'])->name('logout');

    // 2FA Setup (must be accessible before 2fa.verified for forced setup)
    Route::get('two-factor/setup', [TwoFactorController::class, 'setup'])->name('two-factor.setup');
    Route::post('two-factor/confirm', [TwoFactorController::class, 'confirmSetup'])->name('two-factor.confirm');
    Route::post('two-factor/disable', [TwoFactorController::class, 'disable'])->name('two-factor.disable');
    Route::post('two-factor/recovery-codes', [TwoFactorController::class, 'regenerateRecoveryCodes'])->name('two-factor.recovery-codes');
});

Route::middleware(['auth', 'resolve.tenant', 'inject.branding', '2fa.verified'])->group(function () {
    Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Notifications
    Route::get('notifications', [NotificationController::class, 'index'])->name('notifications.index');
    Route::get('notifications/{id}/read', [NotificationController::class, 'markAsRead'])->name('notifications.read');
    Route::post('notifications/mark-all-read', [NotificationController::class, 'markAllRead'])->name('notifications.mark-all-read');

    // Profile
    Route::get('profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::put('profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::put('profile/password', [ProfileController::class, 'updatePassword'])->name('profile.password');

    // Security Settings
    Route::get('settings/security', [SecuritySettingsController::class, 'index'])->name('settings.security');
    Route::put('settings/security/password', [SecuritySettingsController::class, 'updatePassword'])->name('settings.security.password');

    // Active Sessions
    Route::get('sessions', [SessionController::class, 'index'])->name('sessions.index');
    Route::delete('sessions/{session}', [SessionController::class, 'destroy'])->name('sessions.destroy');
    Route::delete('sessions', [SessionController::class, 'destroyAll'])->name('sessions.destroy-all');

    // ── Platform Admin Routes ──
    Route::middleware('role:platform-admin')->prefix('platform')->name('platform.')->group(function () {
        // Tenants
        Route::resource('tenants', TenantController::class);
        Route::post('tenants/{tenant}/toggle-status', [TenantController::class, 'toggleStatus'])->name('tenants.toggle-status');
        Route::post('tenants/{tenant}/users/{user}/reset-password', [TenantController::class, 'resetUserPassword'])->name('tenants.reset-user-password');

        // Tenant SSO Settings
        Route::get('tenants/{tenant}/sso', [TenantSsoController::class, 'index'])->name('tenants.sso.index');
        Route::post('tenants/{tenant}/sso', [TenantSsoController::class, 'store'])->name('tenants.sso.store');
        Route::put('tenants/{tenant}/sso/{sso}', [TenantSsoController::class, 'update'])->name('tenants.sso.update');
        Route::delete('tenants/{tenant}/sso/{sso}', [TenantSsoController::class, 'destroy'])->name('tenants.sso.destroy');

        // Pricing & Commercial
        Route::resource('subscription-plans', SubscriptionPlanController::class)->except('show')->parameters(['subscription-plans' => 'id']);
        Route::post('subscription-plans/{id}/duplicate', [SubscriptionPlanController::class, 'duplicate'])->name('subscription-plans.duplicate');
        Route::get('subscriptions', [TenantSubscriptionController::class, 'index'])->name('subscriptions.index');
        Route::get('subscriptions/create', [TenantSubscriptionController::class, 'create'])->name('subscriptions.create');
        Route::post('subscriptions', [TenantSubscriptionController::class, 'store'])->name('subscriptions.store');
        Route::get('subscriptions/invoices/{invoiceId}', [TenantSubscriptionController::class, 'showInvoice'])->name('subscriptions.invoice');
        Route::get('subscriptions/{id}/edit', [TenantSubscriptionController::class, 'edit'])->name('subscriptions.edit');
        Route::put('subscriptions/{id}', [TenantSubscriptionController::class, 'update'])->name('subscriptions.update');
        Route::post('subscriptions/{id}/invoice', [TenantSubscriptionController::class, 'generateInvoice'])->name('subscriptions.generate-invoice');

        // Platform Settings
        Route::get('settings', [PlatformSettingController::class, 'edit'])->name('settings.edit');
        Route::put('settings', [PlatformSettingController::class, 'update'])->name('settings.update');

        // All Users (cross-tenant view)
        Route::get('users', [PlatformUserController::class, 'index'])->name('users.index');
        Route::post('users/{user}/force-logout', [SessionController::class, 'forceLogout'])->name('users.force-logout');
        Route::post('users/{user}/reset-password', [PlatformUserController::class, 'resetPassword'])->name('users.reset-password');
        Route::delete('users/{user}', [PlatformUserController::class, 'destroy'])->name('users.destroy');

        // Reports & Analytics
        Route::get('reports', [PlatformReportController::class, 'index'])->name('reports.index');
        Route::get('reports/tenant-completion', [PlatformReportController::class, 'tenantCompletion'])->name('reports.tenant-completion');
        Route::get('reports/course-performance', [PlatformReportController::class, 'coursePerformance'])->name('reports.course-performance');
        Route::get('reports/quiz-analytics', [PlatformReportController::class, 'quizAnalytics'])->name('reports.quiz-analytics');

        // Audit Logs
        Route::get('audit-logs', [AuditLogController::class, 'index'])->name('audit-logs.index');
        Route::get('audit-logs/{auditLog}', [AuditLogController::class, 'show'])->name('audit-logs.show');

        // Course Categories
        Route::get('categories', [CourseCategoryController::class, 'index'])->name('categories.index');
        Route::post('categories', [CourseCategoryController::class, 'store'])->name('categories.store');
        Route::put('categories/{category}', [CourseCategoryController::class, 'update'])->name('categories.update');
        Route::delete('categories/{category}', [CourseCategoryController::class, 'destroy'])->name('categories.destroy');

        // Course Management (catalog)
        Route::resource('courses', CourseManagementController::class);
        Route::post('courses/{course}/assign-tenants', [CourseManagementController::class, 'assignTenants'])->name('courses.assign-tenants');

        // Learning Paths (platform)
        Route::resource('learning-paths', PlatformLearningPathController::class)->except(['show']);
        Route::post('learning-paths/{learning_path}/assign-tenants', [PlatformLearningPathController::class, 'assignTenants'])->name('learning-paths.assign-tenants');
        Route::post('courses/{course}/lessons', [CourseManagementController::class, 'storeLesson'])->name('courses.lessons.store');
        Route::put('courses/{course}/lessons/{lesson}', [CourseManagementController::class, 'updateLesson'])->name('courses.lessons.update');
        Route::delete('courses/{course}/lessons/{lesson}', [CourseManagementController::class, 'destroyLesson'])->name('courses.lessons.destroy');
        Route::post('courses/{course}/lessons/reorder', [CourseManagementController::class, 'reorderLessons'])->name('courses.lessons.reorder');
        Route::post('courses/{course}/quiz', [CourseManagementController::class, 'storeQuiz'])->name('courses.quiz.store');
        Route::post('courses/{course}/questions', [CourseManagementController::class, 'storeQuestion'])->name('courses.questions.store');
        Route::delete('courses/{course}/questions/{question}', [CourseManagementController::class, 'destroyQuestion'])->name('courses.questions.destroy');
    });

    // ── Client Admin Routes ──
    Route::middleware('role:platform-admin,client-admin')->prefix('manage')->name('manage.')->group(function () {
        Route::resource('users', UserController::class);
        Route::post('users/{user}/force-logout', [SessionController::class, 'forceLogout'])->name('users.force-logout');
        Route::post('users/import', [UserController::class, 'import'])->name('users.import');
        Route::get('users/export', [UserController::class, 'export'])->name('users.export');
        Route::resource('departments', DepartmentController::class);
        Route::get('audit-logs', [AuditLogController::class, 'index'])->name('audit-logs.index');
        Route::get('audit-logs/{auditLog}', [AuditLogController::class, 'show'])->name('audit-logs.show');

        Route::resource('policies', PolicyController::class);
        Route::post('policies/{policy}/push', [PolicyController::class, 'push'])->name('policies.push');
        Route::get('policies/{policy}/document', [PolicyController::class, 'viewDocument'])->name('policies.document');

        // Announcements
        Route::resource('announcements', ClientAnnouncementController::class)->except(['show'])->parameters(['announcements' => 'id']);
        Route::post('announcements/{id}/publish', [ClientAnnouncementController::class, 'publish'])->name('announcements.publish');

        // Surveys
        Route::resource('surveys', ClientSurveyController::class)->except(['show'])->parameters(['surveys' => 'id']);
        Route::get('surveys/{id}/results', [ClientSurveyController::class, 'results'])->name('surveys.results');

        // Virtual Classrooms
        Route::resource('virtual-classrooms', ClientVirtualClassroomController::class)->except(['show'])->parameters(['virtual-classrooms' => 'id']);
        Route::get('virtual-classrooms/{id}/attendance', [ClientVirtualClassroomController::class, 'attendance'])->name('virtual-classrooms.attendance');
        Route::post('virtual-classrooms/{id}/register-users', [ClientVirtualClassroomController::class, 'registerUsers'])->name('virtual-classrooms.register-users');
        Route::post('virtual-classrooms/{id}/mark-attendance', [ClientVirtualClassroomController::class, 'markAttendance'])->name('virtual-classrooms.mark-attendance');

        Route::resource('phishing', PhishingController::class)->except(['edit', 'update', 'destroy']);
        Route::post('phishing/{campaign}/simulate', [PhishingController::class, 'simulate'])->name('phishing.simulate');

        // Reports
        Route::get('reports', [ClientReportController::class, 'index'])->name('reports.index');
        Route::get('reports/user-progress', [ClientReportController::class, 'userProgress'])->name('reports.user-progress');
        Route::get('reports/department-breakdown', [ClientReportController::class, 'departmentBreakdown'])->name('reports.department-breakdown');
        Route::get('reports/overdue-training', [ClientReportController::class, 'overdueTraining'])->name('reports.overdue-training');
        Route::get('reports/learning-path-progress', [ClientReportController::class, 'learningPathProgress'])->name('reports.learning-path-progress');
        Route::get('reports/survey-analytics', [ClientReportController::class, 'surveyAnalytics'])->name('reports.survey-analytics');
        Route::get('reports/gamification', [ClientReportController::class, 'gamificationReport'])->name('reports.gamification');
        Route::get('reports/export/{type}', [ClientReportController::class, 'exportReport'])->name('reports.export');

        // Tenant settings
        Route::get('settings', [ClientSettingsController::class, 'edit'])->name('settings.edit');
        Route::put('settings', [ClientSettingsController::class, 'update'])->name('settings.update');

        // SSO settings (client-admin self-service)
        Route::get('sso', [ClientSsoController::class, 'index'])->name('sso.index');
        Route::post('sso', [ClientSsoController::class, 'store'])->name('sso.store');
        Route::put('sso/{sso}', [ClientSsoController::class, 'update'])->name('sso.update');
        Route::delete('sso/{sso}', [ClientSsoController::class, 'destroy'])->name('sso.destroy');

        // Client Course Builder
        Route::resource('courses', ClientCourseController::class);
        Route::post('courses/{course}/lessons', [ClientCourseController::class, 'storeLesson'])->name('courses.lessons.store');
        Route::put('courses/{course}/lessons/{lesson}', [ClientCourseController::class, 'updateLesson'])->name('courses.lessons.update');
        Route::delete('courses/{course}/lessons/{lesson}', [ClientCourseController::class, 'destroyLesson'])->name('courses.lessons.destroy');
        Route::post('courses/{course}/quiz', [ClientCourseController::class, 'storeQuiz'])->name('courses.quiz.store');
        Route::post('courses/{course}/questions', [ClientCourseController::class, 'storeQuestion'])->name('courses.questions.store');
        Route::delete('courses/{course}/questions/{question}', [ClientCourseController::class, 'destroyQuestion'])->name('courses.questions.destroy');
        Route::put('courses/{course}/questions/{question}', [ClientCourseController::class, 'updateQuestion'])->name('courses.questions.update');
        Route::post('courses/{course}/lessons/reorder', [ClientCourseController::class, 'reorderLessons'])->name('courses.lessons.reorder');
        Route::get('courses/{course}/preview', [ClientCourseController::class, 'preview'])->name('courses.preview');
        Route::get('courses/{course}/assign-users', [ClientCourseController::class, 'assignUsers'])->name('courses.assign-users');
        Route::post('courses/{course}/assign-users', [ClientCourseController::class, 'assignUsersSave'])->name('courses.assign-users.save');

        // Assignments
        Route::get('assignments', [ClientAssignmentController::class, 'index'])->name('assignments.index');
        Route::get('courses/{course}/assignments/create', [ClientAssignmentController::class, 'create'])->name('assignments.create');
        Route::post('courses/{course}/assignments', [ClientAssignmentController::class, 'store'])->name('assignments.store');
        Route::get('assignments/{assignment}/edit', [ClientAssignmentController::class, 'edit'])->name('assignments.edit');
        Route::put('assignments/{assignment}', [ClientAssignmentController::class, 'update'])->name('assignments.update');
        Route::get('assignments/{assignment}/submissions', [ClientAssignmentController::class, 'submissions'])->name('assignments.submissions');
        Route::get('submissions/{submission}/review', [ClientAssignmentController::class, 'review'])->name('submissions.review');
        Route::post('submissions/{submission}/review', [ClientAssignmentController::class, 'submitReview'])->name('submissions.review.submit');
        Route::get('submissions/{submission}/download', function (\App\Models\AssignmentSubmission $submission) {
            return \Illuminate\Support\Facades\Storage::download($submission->file_path, $submission->file_name);
        })->name('submissions.download');

        // Learning Paths
        Route::resource('learning-paths', ClientLearningPathController::class)->except(['show']);
        Route::get('learning-paths/{learning_path}/assign-users', [ClientLearningPathController::class, 'assignUsers'])->name('learning-paths.assign-users');
        Route::post('learning-paths/{learning_path}/assign-users', [ClientLearningPathController::class, 'assignUsersSave'])->name('learning-paths.assign-users.save');

        // Employee Credentials (manager view)
        Route::get('credentials', [ClientCredentialController::class, 'index'])->name('credentials.index');
        Route::get('credentials/{user}', [ClientCredentialController::class, 'show'])->name('credentials.show');

        // AI Tools
        Route::prefix('ai')->name('ai.')->group(function () {
            Route::get('/', [AiToolsController::class, 'index'])->name('index');
            Route::get('course-generator', [AiToolsController::class, 'courseGenerator'])->name('course-generator');
            Route::post('course-generate', [AiToolsController::class, 'generateCourse'])->name('course-generate');
            Route::post('course-save', [AiToolsController::class, 'saveCourse'])->name('course-save');
            Route::get('quiz-generator', [AiToolsController::class, 'quizGenerator'])->name('quiz-generator');
            Route::post('quiz-generate', [AiToolsController::class, 'generateQuiz'])->name('quiz-generate');
            Route::post('quiz-save', [AiToolsController::class, 'saveQuiz'])->name('quiz-save');
            Route::get('phishing-generator', [AiToolsController::class, 'phishingGenerator'])->name('phishing-generator');
            Route::post('phishing-generate', [AiToolsController::class, 'generatePhishing'])->name('phishing-generate');
            Route::post('phishing-save', [AiToolsController::class, 'savePhishing'])->name('phishing-save');
            Route::get('risk-dashboard', [AiToolsController::class, 'riskDashboard'])->name('risk-dashboard');
        });
    });

    // ── Manager Routes ──
    Route::middleware('role:platform-admin,client-admin,manager')->prefix('team')->name('team.')->group(function () {
        Route::get('members', [UserController::class, 'teamMembers'])->name('members');
        Route::get('reports', [DashboardController::class, 'teamReports'])->name('reports');
    });

    // ── SCORM API (authenticated, CSRF-protected) ──
    Route::post('api/scorm/{lesson}/initialize', [ScormApiController::class, 'initialize'])->name('scorm.initialize');
    Route::post('api/scorm/{lesson}/commit', [ScormApiController::class, 'commit'])->name('scorm.commit');
    Route::post('api/scorm/{lesson}/finish', [ScormApiController::class, 'finish'])->name('scorm.finish');

    // ── Employee Routes (all authenticated users) ──
    Route::prefix('learn')->name('learn.')->group(function () {
        Route::get('courses', [CourseController::class, 'index'])->name('courses.index');
        Route::get('courses/{course}', [CourseController::class, 'show'])->name('courses.show');
        Route::get('courses/{course}/lessons/{lesson}', [CourseController::class, 'lesson'])->name('courses.lesson');
        Route::post('courses/{course}/lessons/{lesson}/complete', [CourseController::class, 'completeLesson'])->name('courses.complete-lesson');
        Route::get('courses/{course}/quiz', [CourseController::class, 'showQuiz'])->name('courses.quiz');
        Route::post('courses/{course}/quiz', [CourseController::class, 'submitQuiz'])->name('courses.submit-quiz');
        Route::get('courses/{course}/quiz-result/{attempt}', [CourseController::class, 'quizResult'])->name('courses.quiz-result');

        Route::get('learning-paths', [EmployeeLearningPathController::class, 'index'])->name('learning-paths.index');
        Route::get('learning-paths/{learning_path}', [EmployeeLearningPathController::class, 'show'])->name('learning-paths.show');

        Route::get('certificates', [CertificateController::class, 'index'])->name('certificates.index');
        Route::get('certificates/{certificate}/download', [CertificateController::class, 'download'])->name('certificates.download');

        // External Credentials (unified view)
        Route::resource('credentials', ExternalCredentialController::class)->except(['show']);
        Route::get('credentials/{credential}/download', [ExternalCredentialController::class, 'download'])->name('credentials.download');

        Route::get('policies', [PolicyAcknowledgmentController::class, 'index'])->name('policies.index');
        Route::get('policies/{policy}', [PolicyAcknowledgmentController::class, 'show'])->name('policies.show');
        Route::post('policies/{policy}/acknowledge', [PolicyAcknowledgmentController::class, 'acknowledge'])->name('policies.acknowledge');
        Route::get('policies/{policy}/document', [PolicyAcknowledgmentController::class, 'viewDocument'])->name('policies.document');

        Route::get('announcements', [EmployeeAnnouncementController::class, 'index'])->name('announcements.index');
        Route::get('announcements/{id}', [EmployeeAnnouncementController::class, 'show'])->name('announcements.show');
        Route::post('announcements/{id}/read', [EmployeeAnnouncementController::class, 'markRead'])->name('announcements.read');

        Route::get('surveys', [EmployeeSurveyController::class, 'index'])->name('surveys.index');
        Route::get('surveys/{id}', [EmployeeSurveyController::class, 'show'])->name('surveys.show');
        Route::post('surveys/{id}', [EmployeeSurveyController::class, 'submit'])->name('surveys.submit');
        Route::get('surveys/{id}/thank-you', [EmployeeSurveyController::class, 'thankYou'])->name('surveys.thank-you');

        Route::get('virtual-classrooms', [EmployeeVirtualClassroomController::class, 'index'])->name('virtual-classrooms.index');
        Route::post('virtual-classrooms/{id}/register', [EmployeeVirtualClassroomController::class, 'register'])->name('virtual-classrooms.register');

        Route::get('assignments', [EmployeeAssignmentController::class, 'index'])->name('assignments.index');
        Route::get('assignments/{assignment}', [EmployeeAssignmentController::class, 'show'])->name('assignments.show');
        Route::post('assignments/{assignment}/submit', [EmployeeAssignmentController::class, 'submit'])->name('assignments.submit');
        Route::get('assignments/{assignment}/my-submission', [EmployeeAssignmentController::class, 'mySubmission'])->name('assignments.my-submission');

        Route::get('leaderboard', [LeaderboardController::class, 'index'])->name('leaderboard.index');
    });
});
